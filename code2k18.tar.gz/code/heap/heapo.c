// Compile with:
//   gcc -o heapo heapo.c

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void main(int argc, char* argv[]) {

		char* user = (char*) malloc(sizeof(char)*8);
		char* admin = (char*) malloc(sizeof(char)*8);

		strcpy(admin, "root");

		if (argc > 1) {
			strcpy(user, argv[1]);
		}
		else {
			strcpy(user, "guest");
		}

		printf("User is at address %p, contains: %s\n", user, user);
		printf("Admin is at address %p, contains: %s\n", admin, admin);

		printf("Giving all the power to %s\n\n", admin);
}
